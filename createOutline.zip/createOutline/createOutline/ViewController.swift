//
//  ViewController.swift
//  WSTagsFieldExample
//
//  Created by Ricardo Pereira on 04/07/16.
//  Copyright © 2016 Whitesmith. All rights reserved.
//

import UIKit
import WSTagsField

class ViewController: UIViewController {
    var keypoints = [String]()
    
    @IBOutlet weak var OutlineTitle: UITextField!
    @IBOutlet weak var keypointTotal: UITextView!
    
    fileprivate let tagsField = WSTagsField()

    @IBOutlet fileprivate weak var tagsView: UIView!
    @IBOutlet weak var anotherField: UITextField!

    //delete outline
    @IBAction func deleteOutline(_ sender: UIButton) {
        let alert = UIAlertController(title: "Are you sure?", message: "removing outline will also remove keypoints", preferredStyle: .alert)

        //if user press YES
        alert.addAction(UIAlertAction(title: "Delete", style: .default, handler: { action in
            //code to remove outline from tableViewCell array
        }))
        
        //if user press NO
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))

        self.present(alert, animated: true)
    }
    @IBOutlet weak var deleteOutline: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        tagsField.frame = tagsView.bounds
        tagsView.addSubview(tagsField)

        //tagsField.translatesAutoresizingMaskIntoConstraints = false
        //tagsField.heightAnchor.constraint(equalToConstant: 150).isActive = true

        tagsField.cornerRadius = 3.0
        tagsField.spaceBetweenLines = 10
        tagsField.spaceBetweenTags = 10

        //tagsField.numberOfLines = 3
        //tagsField.maxHeight = 100.0

        tagsField.layoutMargins = UIEdgeInsets(top: 2, left: 6, bottom: 2, right: 6)
        tagsField.contentInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10) //old padding

        tagsField.placeholder = "Enter Keypoints"
        tagsField.placeholderColor = .gray
        tagsField.placeholderAlwaysVisible = true
        tagsField.backgroundColor = .none
        tagsField.textField.returnKeyType = .continue
        tagsField.delimiter = ","
        print(tagsField.text)
        tagsField.textDelegate = self

        textFieldEvents()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        tagsField.beginEditing()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        tagsField.frame = tagsView.bounds
    }
    
    @IBAction func touchReadOnly(_ sender: UIButton) {
        tagsField.readOnly = !tagsField.readOnly
        sender.isSelected = tagsField.readOnly
    }

    @IBAction func touchChangeAppearance(_ sender: UIButton) {
        tagsField.layoutMargins = UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
        tagsField.contentInset = UIEdgeInsets(top: 2, left: 2, bottom: 2, right: 2) //old padding
        tagsField.cornerRadius = 10.0
        tagsField.spaceBetweenLines = 2
        tagsField.spaceBetweenTags = 2
        tagsField.tintColor = .red
        tagsField.textColor = .systemPink
        tagsField.selectedColor = .yellow
        tagsField.selectedTextColor = .black
        tagsField.delimiter = ","
        tagsField.isDelimiterVisible = true
        tagsField.borderWidth = 2
        tagsField.borderColor = .none
        tagsField.textField.textColor = .green
        tagsField.placeholderColor = .green
        tagsField.placeholderAlwaysVisible = false
        tagsField.font = UIFont.systemFont(ofSize: 90)
        tagsField.keyboardAppearance = .dark
        tagsField.acceptTagOption = .space
    }

    

   

}

extension ViewController {
    func returnKeypoints(lol: String){
        keypoints.append(lol)
    }
    fileprivate func textFieldEvents() {
        tagsField.onDidAddTag = { field, tag in
           
            // Keypoints append
            self.keypoints.append(tag.text)
            print(self.keypoints)
            print("onDidAddTag", tag.text)
            
            //keypoints total changing
            self.keypointTotal.text = "\(self.keypoints.count) Keypoints"
        }

        tagsField.onDidRemoveTag = { field, tag in
            
            print("onDidRemoveTag", tag.text)
            
            //remove keypoint from array
            self.keypoints.index(of: tag.text).map { self.keypoints.remove(at: $0) }
            
            //print(self.keypoints)
        }

        tagsField.onDidChangeText = { _, text in
          
           
            
            print("onDidChangeText")
            
        }

        tagsField.onDidChangeHeightTo = { _, height in
            print("HeightTo \(height)")
        }

        tagsField.onDidSelectTagView = { _, tagView in
            print("Select \(tagView)")
        }

        tagsField.onDidUnselectTagView = { _, tagView in
            print("Unselect \(tagView)")
        }

        tagsField.onShouldAcceptTag = { field in
            return field.text != "OMG"
        }
    }

}

extension ViewController: UITextFieldDelegate {

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == tagsField {
            anotherField.becomeFirstResponder()
        }
        return true
    }

}
